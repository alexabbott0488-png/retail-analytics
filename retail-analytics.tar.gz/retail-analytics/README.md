# RetailSense

Open-source multi-sensor retail analytics platform for real-time customer and product tracking, behavior prediction, and loss prevention. Supports camera, audio, Bluetooth (BLE), and environmental sensors with probabilistic fusion that continues tracking through camera blind spots.

## Features

- **Multi-edition design**: Operator (simple), Admin (configuration), Developer (debug + extensions)
- **Sensor fusion**: Kalman / particle filter based tracking with prediction in occlusion
- **Privacy-by-design**: Anonymous tracks, face blur, no raw audio/BLE storage by default
- **Monitoring**: Prometheus metrics + Grafana dashboards (Admin/Developer only)
- **Deployment**: Docker Compose on Rocky Linux (SELinux-aware); ready for bare-metal Kubernetes or cloud

## Quick Start (Rocky Linux)

```bash
# Clone and enter directory
git clone https://github.com/your-org/retail-analytics.git
cd retail-analytics

# Start core application (operator edition by default)
docker compose up -d

# Start monitoring stack (optional, separate)
cd monitoring && docker compose up -d
```

Access:
- Operator/Admin UI: http://localhost:8080
- API / metrics: http://localhost:8000
- Grafana: http://localhost:3000 (admin / admin by default)

## Editions

Set via environment variable:

```bash
EDITION=operator|admin|developer docker compose up -d
```

- **Operator**: Live tracks, alerts, status. No Grafana link.
- **Admin**: Zone editor, sensor management, Grafana button.
- **Developer**: Debug overlays, raw events, plugin reloading, Grafana button.

## Project Structure

```
retail-analytics/
├── app/                  # Core application
│   ├── core/             # Tracking, events, coverage
│   ├── sensors/          # Camera, audio, BLE, environmental adapters
│   ├── fusion/           # Kalman / particle filter + prediction
│   ├── ui/               # Edition-specific interfaces
│   └── metrics/          # Prometheus instrumentation
├── configs/              # YAML configs per edition
├── monitoring/           # Prometheus + Grafana stack
├── mqtt/                 # MQTT broker config
├── tests/
├── Dockerfile
├── docker-compose.yml
└── README.md
```

## Sensors

| Sensor | Role | Blind-spot Support |
|--------|------|--------------------|
| Camera | Primary detection & tracking | No |
| Audio | Energy / DOA | Yes |
| BLE | RSSI proximity | Yes |
| Environmental | CO / fire / safety | Context |

## License

Apache 2.0 — see LICENSE file.

## Contributing

See docs/CONTRIBUTING.md. All editions share the same core; new sensors or predictors are added as plugins.